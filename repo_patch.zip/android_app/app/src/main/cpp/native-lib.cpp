#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include <opencv2/opencv.hpp>

#define LOG_TAG "native-lib"
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// existing functions...

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_example_advancednativeapp_MainActivity_processYUVPlanesNative(JNIEnv* env, jobject /* this */,
                                                                      jobject yBuf, jobject uBuf, jobject vBuf,
                                                                      jint yRowStride, jint uvRowStride, jint uvPixelStride,
                                                                      jint width, jint height) {
    unsigned char* yPtr = (unsigned char*) env->GetDirectBufferAddress(yBuf);
    unsigned char* uPtr = (unsigned char*) env->GetDirectBufferAddress(uBuf);
    unsigned char* vPtr = (unsigned char*) env->GetDirectBufferAddress(vBuf);
    if (!yPtr || !uPtr || !vPtr) {
        ALOGE("GetDirectBufferAddress returned null");
        return NULL;
    }

    int w = width;
    int h = height;

    int frameSize = w * h;
    std::vector<unsigned char> nv21;
    nv21.resize(frameSize * 3 / 2);

    // Copy Y plane (taking into account row stride)
    for (int row = 0; row < h; ++row) {
        memcpy(&nv21[row * w], yPtr + row * yRowStride, w);
    }

    // U and V planes are subsampled; build interleaved VU (NV21: V then U)
    int halfH = (h + 1) / 2;
    int halfW = (w + 1) / 2;
    unsigned char* chroma = &nv21[frameSize];
    for (int row = 0; row < halfH; ++row) {
        for (int col = 0; col < halfW; ++col) {
            int srcIndex = row * uvRowStride + col * uvPixelStride;
            int dstIndex = row * w + col * 2;
            chroma[dstIndex] = vPtr[srcIndex];       // V
            chroma[dstIndex + 1] = uPtr[srcIndex];   // U
        }
    }

    cv::Mat yuvMat(h + h/2, w, CV_8UC1, nv21.data());
    cv::Mat rgb;
    try {
        cv::cvtColor(yuvMat, rgb, cv::COLOR_YUV2RGB_NV21);
    } catch (cv::Exception& e) {
        ALOGE("OpenCV error: %s", e.what());
        return NULL;
    }

    cv::Mat gray, edges;
    cv::cvtColor(rgb, gray, cv::COLOR_RGB2GRAY);
    cv::Canny(gray, edges, 50, 150);

    int outSize = edges.total() * edges.elemSize();
    jbyteArray out = env->NewByteArray(outSize);
    env->SetByteArrayRegion(out, 0, outSize, (jbyte*) edges.data);
    return out;
}
