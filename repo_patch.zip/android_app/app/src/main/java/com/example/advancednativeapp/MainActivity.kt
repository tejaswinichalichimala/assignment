package com.example.advancednativeapp

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.Image
import android.media.ImageReader
import android.os.Bundle
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.widget.FrameLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.nio.ByteBuffer
import android.os.Handler
import android.os.HandlerThread

class MainActivity : AppCompatActivity() {
    companion object {
        init { System.loadLibrary("native-lib") }
        const val TAG = "MainActivity"
    }

    // Native zero-copy function using direct ByteBuffers for Y, U, V planes
    private external fun processYUVPlanesNative(
        yBuf: java.nio.ByteBuffer,
        uBuf: java.nio.ByteBuffer,
        vBuf: java.nio.ByteBuffer,
        yRowStride: Int,
        uvRowStride: Int,
        uvPixelStride: Int,
        width: Int,
        height: Int
    ): ByteArray

    private lateinit var textureView: TextureView
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var previewSize = Size(1280, 720)
    private var imageReader: ImageReader? = null

    // Simple GL renderer skeleton (you can attach to GLSurfaceView if preferred)
    private var glRenderer: GLRenderer? = null

    // websocket
    private var ws: WebSocket? = null
    private val client = OkHttpClient()

    private var sentHeader = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        textureView = TextureView(this)
        setContentView(FrameLayout(this).apply { addView(textureView) })

        glRenderer = GLRenderer()
        startWebSocket("ws://10.0.2.2:8081") // emulator -> host; change for real device

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        } else {
            textureView.surfaceTextureListener = surfaceListener
        }
    }

    private fun startWebSocket(url: String) {
        val req = Request.Builder().url(url).build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                Log.d(TAG, "WebSocket opened")
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                Log.e(TAG, "WebSocket failure", t)
            }
        })
    }

    private val surfaceListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(st: android.graphics.SurfaceTexture, width: Int, height: Int) {
            startCamera()
        }
        override fun onSurfaceTextureSizeChanged(st: android.graphics.SurfaceTexture, w: Int, h: Int) {}
        override fun onSurfaceTextureDestroyed(st: android.graphics.SurfaceTexture): Boolean { return true }
        override fun onSurfaceTextureUpdated(st: android.graphics.SurfaceTexture) {}
    }

    private fun startCamera() {
        val manager = getSystemService(CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = manager.cameraIdList[0]
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map!!.getOutputSizes(ImageFormat.YUV_420_888)
            previewSize = sizes.firstOrNull() ?: previewSize

            // create ImageReader for YUV_420_888 frames
            imageReader = ImageReader.newInstance(previewSize.width, previewSize.height, ImageFormat.YUV_420_888, 2)
            val handlerThread = HandlerThread("ImageReaderThread")
            handlerThread.start()
            val readerHandler = Handler(handlerThread.looper)
            imageReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                val processed = processYUVImageAndSend(image)
                image.close()
                if (processed != null) {
                    glRenderer?.updateImage(processed, previewSize.width, previewSize.height)
                    // send binary frame via ws
                    try { ws?.send(ByteString.of(processed, 0, processed.size)) } catch (e: Exception) { Log.e(TAG, "ws send failed", e) }
                }
            }, readerHandler)

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
            manager.openCamera(cameraId, stateCallback, null)
        } catch (e: Exception) {
            Log.e(TAG, "startCamera error", e)
        }
    }

    private fun processYUVImageAndSend(image: Image): ByteArray? {
        val width = image.width
        val height = image.height
        val planeY = image.planes[0]
        val planeU = image.planes[1]
        val planeV = image.planes[2]

        val yRowStride = planeY.rowStride
        val uvRowStride = planeU.rowStride
        val uvPixelStride = planeU.pixelStride

        // Use existing ByteBuffer from plane (these are typically direct and backed by native memory)
        val yBuf = planeY.buffer
        val uBuf = planeU.buffer
        val vBuf = planeV.buffer

        // send header once before first frame so web client auto-detects size
        if (!sentHeader) {
            try {
                val hdr = "{"width":$width,"height":$height}"
                ws?.send(hdr)
                sentHeader = true
            } catch (e: Exception) { /* ignore */ }
        }

        // If buffers are not direct, wrap into direct buffers (makes them usable in JNI via GetDirectBufferAddress)
        val yDirect = if (yBuf.isDirect) yBuf else ByteBuffer.allocateDirect(yBuf.remaining()).apply { put(yBuf); position(0) }
        val uDirect = if (uBuf.isDirect) uBuf else ByteBuffer.allocateDirect(uBuf.remaining()).apply { put(uBuf); position(0) }
        val vDirect = if (vBuf.isDirect) vBuf else ByteBuffer.allocateDirect(vBuf.remaining()).apply { put(vBuf); position(0) }

        // call native zero-copy processor
        return try {
            processYUVPlanesNative(yDirect, uDirect, vDirect, yRowStride, uvRowStride, uvPixelStride, width, height)
        } catch (e: Exception) {
            Log.e(TAG, "Native processing failed", e)
            null
        }
    }

    private val stateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            cameraDevice = camera
            createPreviewSession()
        }
        override fun onDisconnected(camera: CameraDevice) { camera.close(); cameraDevice = null }
        override fun onError(camera: CameraDevice, error: Int) { camera.close(); cameraDevice = null }
    }

    private fun createPreviewSession() {
        val st = textureView.surfaceTexture ?: return
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val surface = Surface(st)
        try {
            val previewRequestBuilder = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            previewRequestBuilder.addTarget(surface)
            // also add ImageReader surface so we get frames
            previewRequestBuilder.addTarget(imageReader!!.surface)

            cameraDevice!!.createCaptureSession(listOf(surface, imageReader!!.surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    val previewRequest = previewRequestBuilder.build()
                    session.setRepeatingRequest(previewRequest, null, null)
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {}
            }, null)
        } catch (e: Exception) {
            Log.e(TAG, "createPreviewSession error", e)
        }
    }

    override fun onDestroy() {
        captureSession?.close()
        cameraDevice?.close()
        ws?.close(1000, "bye")
        super.onDestroy()
    }
}
