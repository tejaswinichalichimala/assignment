const img = document.getElementById('frame') as HTMLImageElement;
const stats = document.getElementById('stats') as HTMLDivElement;
let fps = 0;
let frames = 0;
let width = 320;
let height = 240;

setInterval(() => {
  fps = frames;
  frames = 0;
  stats.textContent = `FPS: ${fps} | ${width}x${height}`;
}, 1000);

// connect to websocket
const ws = new WebSocket('ws://' + window.location.hostname + ':8081');
ws.binaryType = 'arraybuffer';
ws.onopen = () => console.log('ws open');

ws.onmessage = (ev) => {
  if (typeof ev.data === 'string') {
    try {
      const hdr = JSON.parse(ev.data);
      if (hdr.width && hdr.height) {
        width = hdr.width;
        height = hdr.height;
        console.log('Received header:', hdr);
      }
    } catch (e) {
      console.warn('Failed to parse header', e);
    }
    return;
  }

  const buf = ev.data as ArrayBuffer;
  const uint8 = new Uint8ClampedArray(buf);
  if (uint8.length < width * height) {
    console.warn('Received frame size smaller than width*height', uint8.length, width * height);
    return;
  }

  // Convert grayscale -> RGBA ImageData
  const rgba = new Uint8ClampedArray(width * height * 4);
  for (let i = 0; i < width * height; i++) {
    const v = uint8[i];
    const idx = i * 4;
    rgba[idx] = v; rgba[idx+1] = v; rgba[idx+2] = v; rgba[idx+3] = 255;
  }

  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  const imgData = new ImageData(rgba, width, height);
  ctx.putImageData(imgData, 0, 0);
  img.src = canvas.toDataURL();
  frames++;
};

export {};
