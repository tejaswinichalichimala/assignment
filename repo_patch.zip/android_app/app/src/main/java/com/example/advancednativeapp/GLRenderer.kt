private const val FRAGMENT_SHADER = """
precision mediump float;
varying vec2 vTexCoord;
uniform sampler2D uTexture;
// simple false-color (jet-like) mapping
vec3 colormap(float v) {
  float r = clamp(1.5 - abs(4.0*(v-0.75)), 0.0, 1.0);
  float g = clamp(1.5 - abs(4.0*(v-0.5)), 0.0, 1.0);
  float b = clamp(1.5 - abs(4.0*(v-0.25)), 0.0, 1.0);
  return vec3(r,g,b);
}
void main() {
  float l = texture2D(uTexture, vTexCoord).r;
  vec3 c = colormap(l);
  gl_FragColor = vec4(c, 1.0);
}"""
