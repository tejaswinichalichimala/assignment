const WebSocket = require('ws');
const express = require('express');
const path = require('path');
const app = express();
const port = 8080;
const wssPort = 8081;

app.use(express.static(path.join(__dirname)));
app.listen(port, () => console.log(`HTTP server running at http://localhost:${port}`));

const wss = new WebSocket.Server({ port: wssPort });
console.log('WebSocket server running on port', wssPort);

wss.on('connection', function connection(ws) {
  console.log('client connected');
  ws.on('message', function incoming(message) {
    // message may be string (JSON header) or binary (frame)
    // broadcast to all clients
    wss.clients.forEach(function each(client) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  });
});
